import User from './pages/User';

function App() {
  return (
    <>
      <User />
    </>
  );
}

export default App;
